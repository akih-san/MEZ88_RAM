#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=Q43Rev1.4.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/Q43Rev1.4.X.production.hex
