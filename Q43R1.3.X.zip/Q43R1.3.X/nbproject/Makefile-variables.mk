#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=Q43R1.3.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/Q43R1.3.X.production.hex
